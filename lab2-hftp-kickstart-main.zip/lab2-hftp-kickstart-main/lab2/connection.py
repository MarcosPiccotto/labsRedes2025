# encoding: utf-8
# Revisión 2019 (a Python 3 y base64): Pablo Ventura
# Copyright 2014 Carlos Bederián
# $Id: connection.py 455 2011-05-01 00:32:09Z carlos $

from base64 import b64encode
from constants import *
import os
import socket

BUFFER_SIZE = 1024

class Connection:
    """
    Conexión punto a punto entre el servidor y un cliente.
    Se encarga de satisfacer los pedidos del cliente hasta
    que termina la conexión.
    """

    def __init__(self, socket, directory):
        """
        Inicializa la conexión con el socket y el directorio proporcionados.
        """
        self.socket = socket
        self.dir = directory
        self.connected = True
        self.buffer = ""
        self.output_buffer = b""  # Buffer para datos pendientes de envío
        self.command = {
            "get_file_listing": self.get_file_listing_handler,
            "get_metadata": self.get_metadata_handler,
            "get_slice": self.get_slice_handler,
            "quit": self.quit_handler,
        }

    def quit_handler(self, args: list[str]):
        """
        Maneja el comando 'quit' para cerrar la conexión.

        Args:
            args: Lista de argumentos que debe estar vacia para este comando.

        Return:
            INVALID_ARGUMENTS si se proporciona algún argumento.
        """
        if len(args) != 0:
            return INVALID_ARGUMENTS
        self.connected = False
        self.load_buffer(CODE_OK)

    def get_file_listing_handler(self, _):
        """
        Maneja el comando 'get_file_listing' para listar los archivos del directorio.

        Return:
            UnicodeEncodeError si algun nombre de archivo no tiene formato ASCII.
        """
        list = os.listdir(self.dir)
        body = ""
        for l in list:
            try:
                l.encode("ascii")
                body += f"{l}{EOL}"
            except UnicodeEncodeError:
                return UnicodeEncodeError
        self.load_buffer(CODE_OK, body)

    def get_size(self, filepath: str) -> int:
        """
        Obtiene el tamaño de un archivo en Bytes.

        Args:
            filepath: Ruta relativa del archivo

        Return:
            El tamaño en Bytes del archivo o -1 si no existe.
        """
        filepath = os.path.join(self.dir, filepath)
        try:
            size = os.path.getsize(filepath)
            return size
        except:
            if not os.path.isfile(filepath):
                return -1

    def get_metadata_handler(self, args: list[str]):
        """
        Maneja el comando 'get_metadata' para obtener el tamaño de un archivo.

        Args:
            args: Lista de argumentos que debe contener solo el nombre del archivo.

        Return:
            INVALID_ARGUMENTS si hay mas de un argumento.
            FILE_NOT_FOUND si el archivo no existe.
        """
        if len(args) != 1:
            return INVALID_ARGUMENTS

        size = self.get_size(args[0])
        if size == -1:
            return FILE_NOT_FOUND

        self.load_buffer(CODE_OK, str(size))

    def get_slice_handler(self, args: list[str]):
        """
        Maneja el comando 'get_slice' para obtener una porción de un archivo.

        Args:
            args: Lista de argumentos (nombre_archivo, offset, tamaño)

        Return:
            INVALID_ARGUMENTS si los argumentos son inválidos
            FILE_NOT_FOUND si el archivo no existe
            BAD_OFFSET si el offset + tamaño excede el tamaño del archivo
            OSError si ocurre un error al leer el archivo
        """
        if len(args) != 3:
            return INVALID_ARGUMENTS

        filename, offset, size_cut = args

        try:
            offset = int(offset)
            size_cut = int(size_cut)
        except ValueError:
            return INVALID_ARGUMENTS

        if offset < 0 or size_cut < 0:
            return INVALID_ARGUMENTS

        size = self.get_size(filename)
        if size == -1:
            return FILE_NOT_FOUND

        if offset + size_cut > size:
            return BAD_OFFSET

        try:
            filepath = os.path.join(self.dir, filename)
            with open(filepath, "rb") as f:
                f.seek(offset)
                body = f.read(size_cut)

            body_base64 = b64encode(body).decode("utf-8")
            self.load_buffer(CODE_OK, body_base64)
        except FileNotFoundError:
            return FILE_NOT_FOUND
        except OSError:
            return OSError

    def load_buffer(self, error_code: int, body: str = ""):
        """
        Prepara los datos para enviar y los almacena en el buffer de salida.

        Args:
            error_code (int): Código de error.
            body (str): Mensaje para el cliente.
        """
        prefix = f"{error_code} {error_messages[error_code]}{EOL}"
        res = f"{prefix}{body}{EOL}"
        self.output_buffer += res.encode(
            "ascii"
        )  # Agrega los datos al buffer de salida
        self.send()

    def send(self):
        """
        Intenta enviar los datos pendientes en el buffer de salida.
        """
        while self.output_buffer:
            try:
                sent = self.socket.send(self.output_buffer)  # Envía los datos
                self.output_buffer = self.output_buffer[
                    sent:
                ]  # Elimina los datos enviados
            except socket.error as e:
                if e.errno in (socket.errno.EAGAIN, socket.errno.EWOULDBLOCK):
                    # Si el socket no está listo para enviar, espera y reintenta
                    break
                else:
                    # Otro error, cerrar la conexión
                    print(f"Error al enviar datos: {e}")
                    self.connected = False
                    break

    def _read_line(self):
        """Lee una línea del cliente."""
        while EOL not in self.buffer and self.connected:
            try:
                data = self.socket.recv(BUFFER_SIZE).decode("ascii")
                if not data:
                    print("Cliente cerró la conexión o no envió datos.")
                    self.connected = False
                    break
                self.buffer += data
            except BlockingIOError:
                # No hay datos disponibles en el socket, continúa esperando
                break
            except (socket.error, UnicodeDecodeError) as e:
                print(f"Error al leer datos: {e}")
                self.connected = False
                return ""

        if EOL in self.buffer:
            line, self.buffer = self.buffer.split(EOL, 1)

            # Verificar si contiene caracteres no válidos
            if "\n" in line or "\r" in line:
                self.load_buffer(BAD_EOL)
                self.connected = False
                return ""

            # Limpiar la línea después de verificar
            line = line.strip()
            return line
        return ""

    def handle(self):
        """
        Atiende eventos de la conexión hasta que termina.
        """
        while self.connected:
            command = self._read_line()

            if not command:
                continue

            parts = command.split()
            if not parts:
                continue

            cmd = parts[0].lower()
            args = parts[1:]

            if cmd in self.command:
                try:
                    error_code = self.command[cmd](args)

                    if valid_status(error_code):
                        self.load_buffer(error_code)

                        if fatal_status(error_code):
                            self.connected = False

                except (OSError, Exception) as e:
                    print(f"Unexpected OS error: {e}, command: {command}")
                    self.load_buffer(INTERNAL_ERROR)
                    self.connected = False
            else:
                self.load_buffer(INVALID_COMMAND)

            self.send()

        self.socket.close()
        return False

    def can_pollout(self):
        """
        Indica si el cliente necesita enviar datos.
        """
        return len(self.output_buffer) > 0
