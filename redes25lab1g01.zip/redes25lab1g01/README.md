# API de Gestión de Películas

Esta API permite gestionar una base de datos de películas con funcionalidades para agregar, eliminar, actualizar y obtener películas según diferentes criterios.

## Video de presentación
- https://drive.google.com/file/d/1wORBhhQGKd7IK3ZJxCWk67Y1FqfE1e1M/view?usp=sharing

## Instalación y Configuración

1. Crear un entorno virtual de Python utilizando venv y activarlo:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

2. Instalar las dependencias necesarias dentro del entorno:
   ```bash
   pip install -r extra/requirements.txt
   ```

3. Ejecutar la API estando en el directorio redes25lab1g01:
   ```bash
   python3 -m lab1.main
   ```
   - Esto para ejecutarlo como módulo, por la forma en la que hacemos las importaciones

## Endpoints

### Obtener todas las películas
**GET** `/peliculas`
- Retorna la lista completa de películas disponibles.

### Obtener una película por ID
**GET** `/peliculas/<id>`
- Parámetros:
  - `id`: Identificador de la película.
- Retorna los detalles de la película o un error si el ID es inválido.

### Agregar una nueva película
**POST** `/peliculas`
- Cuerpo de la solicitud (JSON):
  ```json
  {
    "titulo": "Nombre de la película",
    "genero": "Género de la película"
  }
  ```
- Retorna:
  - 201 si la película se agregó correctamente.
  - 202 si la película ya existe.
  - 400 si faltan parámetros obligatorios.

### Actualizar una película
**PUT** `/peliculas/<id>`
- Parámetros:
  - `id`: Identificador de la película.
- Cuerpo de la solicitud (JSON):
  ```json
  {
    "titulo": "Nuevo nombre de la película",
    "genero": "Nuevo género de la película"
  }
  ```
- Retorna:
  - 200 si la actualización fue exitosa.
  - 400 si el ID es inválido o si se intenta modificar el ID.

### Eliminar una película
**DELETE** `/peliculas/<id>`
- Parámetros:
  - `id`: Identificador de la película.
- Retorna:
  - 200 si la película se eliminó correctamente.
  - 400 si el ID es inválido.

### Obtener películas por género
**GET** `/peliculas/genero/<genero>`
- Parámetros:
  - `genero`: Género de las películas a buscar.
- Retorna una lista de películas del género especificado.

### Obtener películas por palabra clave en el título
**GET** `/peliculas/<palabra>`
- Parámetros:
  - `palabra`: Palabra clave a buscar en los títulos de las películas.
- Retorna una lista de películas cuyo título contiene la palabra clave.

### Obtener una película aleatoria
**GET** `/peliculas/random`
- Retorna una película aleatoria de la base de datos.

### Obtener una película aleatoria por género
**GET** `/peliculas/random/<genero>`
- Parámetros:
  - `genero`: Género de la película a obtener aleatoriamente.
- Retorna una película aleatoria del género especificado.

### Obtener una película recomendada según el próximo feriado
**GET** `/peliculas/feriado/<genero>`
- Parámetros:
  - `genero`: Género de la película a recomendar.
- Parámetro opcional:
  - `tipo`: Tipo de feriado (`inamovible`, `trasladable`, `nolaborable`, `puente`).
- Retorna una película aleatoria del género especificado junto con información sobre el próximo feriado.
- Agregando el parametro opcional, nos retornara una pelicula junto con el feriado o un error en otro caso.
