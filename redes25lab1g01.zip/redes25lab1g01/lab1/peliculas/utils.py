from re import fullmatch
from unicodedata import category, normalize
from ..data import peliculas

def id_invalido(id):
    """
    Verfica que un id este en rango valido

    Retorna:
    True si esta en rango valido
    False si no esta en rango valido
    """
    return id < 1 or id > len(peliculas)


def input_convertidor(input):
    """
    Convierte el input a un string sin mayúsculas, espacios y tildes.

    Retorna:
    input convertido.
    """
    return "".join(
        c for c in normalize("NFD", input.lower()) if category(c) != "Mn"
    ).replace(" ", "")


def obtener_nuevo_id():
    """
    Obtener un nuevo id.

    Retorna:
    Un id (int).
    """
    if len(peliculas) > 0:
        ultimo_id = peliculas[-1]["id"]
        return ultimo_id + 1
    else:
        return 1
