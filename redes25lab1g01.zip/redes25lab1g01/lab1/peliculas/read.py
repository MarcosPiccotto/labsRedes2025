from flask import jsonify, request
from random import randint
from .utils import input_convertidor, id_invalido
from ..data import peliculas
from ..proximo_feriado.proximo_feriado import NextHoliday


def obtener_peliculas():
    """
    Obtiene la lista completa de películas disponibles.

    Retorna:
    Un objeto JSON con la lista de películas.
    """
    dicc_res = [pelicula.copy() for pelicula in peliculas]

    for pelicula in dicc_res:
        del pelicula["titulo_bd"]
        del pelicula["genero_bd"]

    return jsonify(dicc_res), 200


def obtener_pelicula(id):
    """
    Busca una película por su ID y devuelve sus detalles en formato JSON.

    Parámetros:
    id (int): Identificador de la película a buscar.

    Assert:
    comprobamos si id esta en rango valido (0 < id < len peliculas).

    Retorna:
    200 si la película se agregó correctamente.
    400 si el id es invalido.
    """
    if id_invalido(id):
        return jsonify({"Error": "ID de película inválido"}), 400

    pelicula_encontrada = peliculas[id - 1].copy()
    del pelicula_encontrada["titulo_bd"]
    del pelicula_encontrada["genero_bd"]

    return jsonify(pelicula_encontrada), 200


def obtener_peliculas_genero(genero):
    """
    Devuelve el listado de peliculas segun el genero

    Parametros:
    genero (string)

    Retorna:
    200: Listado de peliculas de cierto genero
    400: El genero no se encuentra.
    """
    genero = input_convertidor(genero)
    peliculas_gen = []

    for pelicula in peliculas:
        if pelicula["genero_bd"] == genero:
            peliculas_gen.append(pelicula.copy())

    if not peliculas_gen:
        return jsonify({"Error": "Género no encontrado"}), 200

    for pelicula in peliculas_gen:
        del pelicula["titulo_bd"]
        del pelicula["genero_bd"]

    return jsonify(peliculas_gen), 200


def obtener_peliculas_palabra(palabra):
    """
    Devuelve un listado de películas que contienen el string de la variable palabra en el título.

    Parámetros:
    palabra (string)

    Retorna:
    200: Listado de peliculas con la palabra incluida
    400: No hay peliculas con esa palabra.
    """
    palabra = input_convertidor(palabra)
    peliculas_palabra = []

    for pelicula in peliculas:
        if palabra in pelicula["titulo_bd"]:
            peliculas_palabra.append(pelicula.copy())

    for pelicula in peliculas_palabra:
        del pelicula["titulo_bd"]
        del pelicula["genero_bd"]

    return jsonify(peliculas_palabra), 200


def obtener_pelicula_random():
    """
    Obtiene una pelicula random.

    Retorna:
    200: JSON con detalles de una pelicula random
    """
    rand = randint(0, len(peliculas) - 1)
    peli_random = peliculas[rand].copy()
    del peli_random["titulo_bd"]
    del peli_random["genero_bd"]

    return jsonify(peli_random), 200


def obtener_pelicula_random_gen(genero):
    """
    Crea una lista con las peliculas del genero elegido.

    Parametros:
    genero (string)

    Retorna:
    200: JSON con detalles de una pelicula random de cierto genero
    400: No hay peliculas de este genero
    """
    genero = input_convertidor(genero)
    pelicula_rand_gen = []

    for pelicula in peliculas:
        if pelicula["genero_bd"] == genero:
            pelicula_rand_gen.append(pelicula.copy())

    if not pelicula_rand_gen:
        return jsonify({"Error": "No hay películas de ese género"}), 200

    rand_gen = randint(0, len(pelicula_rand_gen) - 1)
    peli_random_gen = pelicula_rand_gen[rand_gen]
    del peli_random_gen["titulo_bd"]
    del peli_random_gen["genero_bd"]

    return jsonify(peli_random_gen), 200


def obtener_pelicula_feriado(genero):
    """
    Obtiene el proximo feriado con la API externa y una pelicula random segun algun genero.

    Parametros:
    genero (string)

    Retorna:
    200: JSON con detalles de una pelicula random de cierto genero
    200: No hay peliculas de este genero o no hay un feriado del tipo solicitado(opcional)
    400: Tipo no valido
    """
    tipo = request.args.get("tipo", None)
    if tipo != None:
        tipo = tipo.lower()

    tipos = [None, "inamovible", "trasladable", "nolaborable", "puente"]
    if not (tipo in tipos):
        return jsonify({"error": "Tipo no valido"}), 400

    next_holiday = NextHoliday()
    next_holiday.fetch_holidays(tipo)
    if len(next_holiday.holiday) == 1:
        return jsonify(next_holiday.holiday), 200

    genero = input_convertidor(genero)
    pelicula_rand_gen = []

    for pelicula in peliculas:
        if pelicula["genero_bd"] == genero:
            pelicula_rand_gen.append(pelicula)
    if not pelicula_rand_gen:
        return jsonify({"error": "No hay películas de ese género"}), 200

    rand_gen = randint(0, len(pelicula_rand_gen) - 1)
    peli_random_gen = pelicula_rand_gen[rand_gen]

    eleccion = {
        "id": peli_random_gen["id"],
        "titulo": peli_random_gen["titulo"],
        "genero": peli_random_gen["genero"],
        "motivo": next_holiday.holiday["motivo"],
        "dia": next_holiday.holiday["dia"],
        "mes": next_holiday.holiday["mes"],
        "tipo": next_holiday.holiday["tipo"],
    }

    return jsonify(eleccion), 200
