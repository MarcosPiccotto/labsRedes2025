from flask import jsonify, request
from .utils import obtener_nuevo_id, input_convertidor
from ..data import peliculas


def agregar_pelicula():
    """
    Agrega una nueva película a la lista.

    Retorna:
    201 si la película se agregó correctamente, junto con la película agregada.
    202 si la pelicula ya está en la base de datos
    400 si faltan parámetros obligatorios.
    """
    pelicula_nueva = request.json
    campos_pelicula_nueva = pelicula_nueva.keys()
    pelicula_nueva["titulo_bd"] = input_convertidor(pelicula_nueva["titulo"])

    if "titulo" not in campos_pelicula_nueva or "genero" not in campos_pelicula_nueva:
        return jsonify({"error": "formato inválido"}), 400

    for pelicula in peliculas:
        if pelicula["titulo_bd"] == pelicula_nueva["titulo_bd"]:
            res = pelicula.copy()
            del res["titulo_bd"]
            del res["genero_bd"]
            return jsonify(res), 202

    res = {
        "id": obtener_nuevo_id(),
        "titulo": pelicula_nueva["titulo"],
        "genero": pelicula_nueva["genero"],
    }

    pelicula_nueva = {
        **res,
        "titulo_bd": pelicula_nueva["titulo_bd"],
        "genero_bd": input_convertidor(pelicula_nueva["genero"]),
    }

    peliculas.append(pelicula_nueva)
    return jsonify(res), 201
