from flask import jsonify, request
from .utils import id_invalido, input_convertidor
from ..data import peliculas


def actualizar_pelicula(id):
    """
    Actualiza una película por su ID y devuelve sus detalles en formato JSON.

    Parámetros:
    id (int): Identificador de la película a buscar.

    Retorna:
    200 si la película se agregó correctamente.
    400 si el id es invalido o se intenta modificar el id.
    """
    if id_invalido(id):
        return jsonify({"error": "ID de película inválido"}), 400

    pelicula_nueva = request.json
    if "id" in pelicula_nueva.keys():
        return jsonify({"error": "No esta permitido editar el ID"}), 400

    res = {"id": id, **pelicula_nueva}

    pelicula_nueva = {
        **res,
        "titulo_bd": res["titulo"],
        "genero_bd": input_convertidor(res["genero"]),
    }

    peliculas[id - 1] = pelicula_nueva

    return jsonify(res), 200
